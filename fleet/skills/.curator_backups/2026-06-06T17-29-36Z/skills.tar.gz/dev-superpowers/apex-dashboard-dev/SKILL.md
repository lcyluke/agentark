---
name: apex-dashboard-dev
description: Apex Dashboard 全栈扩展模式 — 如何给 Fleet Manager Tab 添加新按钮/功能，涵盖后端 fleet_manager.py → web.py API 路由 → dashboard_v5.html 前端三层的完整模板。
category: dev-superpowers
triggers:
  - Apex Dashboard 添加新功能/按钮
  - Fleet Manager Tab 扩展
  - dashboard_v5.html 修改
  - 用户说"给 Dashboard 加个按钮"
  - Apex profile/team CRUD 操作
---

# 🦅 Apex Dashboard 全栈扩展模式

## 两个 Dashboard

Apex 有两个前端入口，**老卢主用 `/cc`**：

| 路由 | 模板 | 架构 | 用途 |
|:--|:--|:--|:--|
| `/cc` | `command_center.html` | 侧栏导航 + 9 视图 | **主力** — 老卢日常使用 |
| `/v5` | `dashboard_v5.html` | 顶部 Tab 切换 | 旧版，仍可用 |

## 架构三层

```
后端逻辑层:    apex/interface/fleet_manager.py 或 gpu_manager.py
    ↓ (import)
API 路由层:    apex/interface/web.py
    ↓ (fetch)
前端展示层:    apex/interface/templates/command_center.html  ← 主力
               apex/interface/templates/dashboard_v5.html   ← 旧版
```

**关键路径：** `~/Desktop/2026AIAPP/Apex/apex/interface/`

## ⚠️ JS 安全编码规则 (CRITICAL)

**在 command_center.html 中写 JS 时，永远避免模板字符串（反引号）生成 HTML。**

❌ 危险 — patch 工具可能截断多行模板字符串：
```javascript
return `<div class="${cardClass}" onclick="...">
  <div class="fcan">${canTag}</div>
</div>`;
```

✅ 安全 — 字符串拼接永远不会被截断：
```javascript
return '<div class="'+cardClass+'" onclick="...">' +
  '<div class="fcan">'+canTag+'</div>' +
  '</div>';
```

**原因：** patch 工具的 `old_string`/`new_string` 匹配可能意外截断模板字符串的反引号，导致后续 HTML 标签被 JS 解析器当作语法错误。

## 修改后验证流程 (MANDATORY)

每次修改 JS 后必须执行：

```bash
# 1. 验证 JS 语法
curl -s --max-time 5 http://localhost:8080/cc -o /tmp/cc_test.html
# Extract <script>...</script> and run:
node --check /tmp/cc_js.js

# 2. 如果 node --check 报错 → git checkout 恢复 → 重新干净修改
cd ~/Desktop/2026AIAPP/Apex
git checkout -- apex/interface/templates/command_center.html
# 然后重新 apply 你的改动

# 3. 语法通过后 → 重启服务器
kill $(lsof -ti:8080)
cd ~/Desktop/2026AIAPP/Apex && .venv/bin/python3 -c "from apex.interface.web import run_dashboard; run_dashboard()" &

# 4. 浏览器验证
open http://localhost:8080/cc
```

## /cc 添加新视图的完整模板

### Phase 1: 后端逻辑

新建或扩展 `apex/interface/xxx_manager.py`，返回 dict。惯例：
- 成功: `{"ok": True, ...}`
- 失败: `{"error": "message"}`

### Phase 2: API 路由 (web.py)

在 `create_app()` 内添加路由。务必检查函数名不重复。新增路由加在现有 fleet 路由之后、Task Management 之前。

### Phase 3: 前端 (command_center.html)

三步走：

**A. 侧栏入口** — 在 `<aside class="side">` 的对应分区添加 nav：
```html
<div class="nav" data-view="gpu" onclick="go('gpu')"><i class="ti ti-xxx"></i>名称</div>
```

**B. 视图容器** — 在最后一个 `</section>` 之后、`</div></main>` 之前添加：
```html
<section class="view" id="v-gpu">
  <div class="sec-h">标题</div>
  <div class="kpis" id="gpuKpis"></div>
  <!-- ... -->
</section>
```

**C. JS 函数** — 添加三处：
1. `VIEW_TITLES` 字典: `gpu: ['GPU 资源中心', 'GPU Resource Center']`
2. `renderActiveView()` switch: `case 'gpu': renderGPU(); break;`
3. 视图函数: 在 `/* ========== Events ========== */` 之前添加 `async function renderGPU() { ... }`

JS 中生成 HTML 用字符串拼接，不用模板字符串。

### Phase 1 示例: 后端逻辑 (fleet_manager.py)

在 `fleet_manager.py` 中添加纯函数，返回 dict：

```python
def my_action(name: str) -> dict:
    """Action description"""
    pdir = PROFILES_DIR / name
    if not pdir.exists():
        return {"error": f"Profile '{name}' not found"}
    
    # ... 业务逻辑 ...
    
    return {"ok": True, "profile": name, "result": "..."}
```

**惯例：**
- 返回值统一用 `{"ok": True, ...}` 或 `{"error": "..."}`
- 函数间用 `# ═══════` 分隔
- `import shutil` 可以放在函数内部（避免顶层导入未使用警告）

### Phase 2: API 路由 (web.py)

在 `web.py` 的 fleet 路由区块中添加：

```python
@app.route("/api/fleet/profiles/<name>/my-action", methods=["POST"])
def api_fleet_my_action(name: str):
    """API description"""
    try:
        from apex.interface.fleet_manager import my_action
        data = request.get_json(force=True) or {}
        return jsonify(my_action(name, **data))
    except Exception as e:
        return jsonify({"error": str(e)}), 500
```

**Pitfall:** 路由函数名不能重复。LSP 会报 `jsonify`/`request` 未绑定 — 这是误报，Flask 闭包内可用。路由需在 `create_app()` 函数体内注册。

### Phase 3: 前端 (dashboard_v5.html)

#### CSS
添加按钮样式到 `<style>` 块（在 `.fleet-status-dot` 样式之后）：

```css
.fleet-btn.my-action{background:var(--xxx-bg);color:var(--xxx);border-color:var(--xxx)}
.fleet-btn.my-action:hover{background:var(--xxx);color:#fff}
```

变量系统：
- `--green`/`--green-bg` — 成功/启用
- `--red`/`--red-bg` — 危险/禁用
- `--accent`/`--accent-glow` — 编辑/主要操作
- `--cyan`/`--cyan-bg` — 复制
- `--yellow`/`--yellow-bg` — 警告
- `--purple`/`--purple-bg` — 特殊

#### JS 函数
在 `deleteFleetProfile` 函数之后添加异步函数：

```javascript
async function myFleetAction(name){
  try{
    const r=await fetch('/api/fleet/profiles/'+encodeURIComponent(name)+'/my-action',{method:'POST'});
    if(!r.ok)throw new Error('HTTP '+r.status);
    const data=await r.json();
    addLog('success','Action on '+name+' completed');
    loadAll();  // 刷新数据
  }catch(e){
    addLog('error','Action failed: '+e.message);
    alert('Failed: '+e.message);
  }
}
```

#### 卡片按钮
在 `renderTab8()` 的 profile card 渲染中添加按钮（在 `.profile-actions` div 内）：

```javascript
el('button',{class:'fleet-btn my-action',onclick:function(e){
  e.stopPropagation();  // 防止触发卡片点击
  myFleetAction(p.name);
}},'🎯 Label'),
```

**Pitfall:** `default` profile 不应有破坏性按钮（toggle/delete）。用三元表达式跳过：
```javascript
p.is_default?'':el('button',...)
```
并用 `.filter(Boolean)` 过滤掉空值。

## 已验证的模式

### Enable/Disable 模式
- 后端: `.disabled` 标记文件 → `toggle_profile()` 
- 前端: `isDisabled` 状态 → 灰化卡片(opacity:0.5) + 按钮文字切换
- 卡片 class: `profile-card disabled`

### Copy 模式
- 后端: `shutil.copytree()` + SOUL.md 名称替换 + 移除 `.disabled`
- 前端: `prompt()` 获取新名称 → POST 请求 → `loadAll()` 刷新

### Team 操作按钮
Team 卡片按钮放在 `ftc-name` 同级 flex 容器中，使用 `.fleet-btn` 样式。

## 重启 Dashboard

```bash
# 找到并杀死旧进程
kill $(lsof -ti:8080)

# 启动（必须用 run_dashboard，不能在 -m 下直接启动）
cd ~/Desktop/2026AIAPP/Apex && .venv/bin/python3 -c "
from apex.interface.web import run_dashboard
run_dashboard()
" &

# 确认运行
sleep 2 && lsof -ti:8080
```

**Pitfall:** `python3 -m apex.interface.web` 不能直接启动，因为 web.py 没有 `if __name__ == "__main__"` 块，必须显式调用 `run_dashboard()`。

## 验证

```bash
# 检查 JS 语法 (每次修改后必须)
curl -s http://localhost:8080/cc -o /tmp/cc.html
python3 -c "import re,subprocess,os;html=open('/tmp/cc.html').read();m=re.search(r'<script>(.*?)</script>',html,re.DOTALL);js=m.group(1);open('/tmp/cc_js.js','w').write(js);r=subprocess.run(['node','--check','/tmp/cc_js.js'],capture_output=True,text=True);print(r.stderr or '✅ OK')"

# 检查 API
curl -s http://localhost:8080/api/gpu/status
curl -s http://localhost:8080/api/fleet/profiles/list

# 浏览器验证
open http://localhost:8080/cc  # 主力入口
open http://localhost:8080/v5  # 旧版入口
```

## 文件位置

| 层 | 文件 |
|:--|:--|
| 后端逻辑 | `apex/interface/fleet_manager.py` (Profiles/Teams) |
| 后端逻辑 | `apex/interface/gpu_manager.py` (GPU 资源) |
| API 路由 | `apex/interface/web.py` |
| /cc 前端 | `apex/interface/templates/command_center.html` (**主力**) |
| /v5 前端 | `apex/interface/templates/dashboard_v5.html` (旧版) |
