---
name: apex-cost-tracker
description: Apex LLM token cost tracking — per-cron-job, per-agent, per-project breakdown from Hermes state.db. Dashboard cost center at /cost, 7 API endpoints, real-time monitoring.
version: 1.0.0
tags: [apex, cost-tracking, token-economy, dashboard, cron, budget]
related_skills: [monitoring-system, fleet-monitor, deepseek-provider]
---

# 💰 Apex 成本追踪引擎

> 追踪每一个 LLM token 的成本：按 Cron 任务、Agent Profile、项目、来源渠道分解。

## 架构

```
Hermes state.db (sessions table)
        │
        ▼
apex/cost_tracker.py          ← 成本查询引擎
        │
        ├── /api/cost/summary       ← 总览
        ├── /api/cost/cron?days=30  ← Cron明细
        ├── /api/cost/agents        ← Agent明细
        ├── /api/cost/sources       ← 渠道分解
        ├── /api/cost/projects      ← 项目聚合
        ├── /api/cost/timeline      ← 趋势
        └── /api/cost/full          ← 完整快照
                │
                ▼
/cost (Dashboard)              ← 成本控制中心 HTML
```

## 数据源

- **Hermes state.db** `sessions` 表：`input_tokens`, `output_tokens`, `estimated_cost_usd`, `source`, `handoff_platform`
- Session ID 格式 `cron_{job_id}_{date}_{time}` → 可解析出 cron job ID
- `hermes cron list` → cron job 名称映射

## Cron Job 成本解析

Session ID 格式：`cron_b8ede7ee7204_20260530_090050`，其中 `b8ede7ee7204` 是 job ID。通过此 ID 反查到 `hermes cron list` 中的任务名称。

### 典型成本数据 (DeepSeek V4 Pro)

| Cron类型 | 均次Token | 均次成本 | 月成本估算 |
|:--|:--|:--|:--|
| PM日报 (含system prompt) | ~28K | $0.05 | ~$1.50 |
| 任务监控 (30min) | ~2.8K | $0.006 | ~$0.43 |
| 舰队巡检 (no-agent) | ~1K | $0.002 | ~$0.02 |
| 高频同步 (5min) | ~1.7K | $0.004 | ~$4.20 |

> PM日报的 token 消耗大头是 System Prompt（SOUL.md + MEMORY + USER.md + Skills list），而非实际监测内容。

## 定价参考

```python
PRICING = {
    "deepseek-v4-pro": {"input": 1.0, "output": 4.0},   # $/1M tokens
    "deepseek-chat":   {"input": 0.14, "output": 0.28},
    "claude-sonnet-4": {"input": 3.0, "output": 15.0},
}
```

## Dashboard 使用

访问 `http://localhost:8080/cost`，4 个 Tab：

1. **📋 定时任务成本** — 每个 Cron 的 30 天成本、均次成本、频率、最后运行时间
2. **🤖 Agent成本** — 按 Hermes Profile 分解，显示来源分布
3. **📦 项目成本** — 羽球宝/Apex/FinOps/深圳地图 预算使用率
4. **📈 趋势** — 7 天 token 量柱状图 + 成本折线图

顶部 6 个 Summary Card：今日/本周/30天/累计/日均/预估月成本，30 秒自动刷新。

## API 速查

```bash
curl http://localhost:8080/api/cost/summary
curl http://localhost:8080/api/cost/cron?days=7
curl http://localhost:8080/api/cost/agents
curl http://localhost:8080/api/cost/projects
curl http://localhost:8080/api/cost/timeline?days=7&granularity=daily
curl http://localhost:8080/api/cost/full
```

## 项目成本估算

基于 session title/system_prompt 中的关键词启发式匹配：

```python
PROJECT_KEYWORDS = {
    "badminton-coach-ai": {"name": "羽球宝AI搭子", "emoji": "🏸", "budget": 5.0, "keywords": ["badminton", "羽球"]},
    "apex": {"name": "Apex Dashboard", "emoji": "🦅", "budget": 10.0, "keywords": ["apex", "dashboard"]},
    "finopsai": {"name": "FinOps AI", "emoji": "💰", "budget": 5.0, "keywords": ["finops", "billing"]},
    "shenzhen-badminton": {"name": "深圳羽球地图", "emoji": "🗺️", "budget": 3.0, "keywords": ["深圳", "地图"]},
}
```

## 关键文件

| 文件 | 说明 |
|:--|:--|
| `apex/cost_tracker.py` | 成本查询引擎 (~350行) |
| `apex/interface/templates/cost_center.html` | Dashboard 视图 |
| `apex/interface/web.py` | +7个 API 端点 + `/cost` 路由 |

## 参考数据

- `references/cron-cost-data-2026-06.md` — 实际 cron 成本快照 (2026-06-07)，16个任务排名 + 渠道分解

## 注意事项

- Cron session 的 `title` 字段通常为空，需从 session ID 解析 job ID
- Agent 成本按 `handoff_platform` 分组（比 `source` 更细）
- 项目成本是启发式估算（关键词匹配），非精确分配
- `no_agent=true` 的 cron（纯脚本）不产生 LLM 成本，仅在 delivery 时可能有少量 token
