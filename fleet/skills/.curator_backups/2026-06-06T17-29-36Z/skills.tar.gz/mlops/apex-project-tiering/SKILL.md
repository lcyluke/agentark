---
name: apex-project-tiering
description: "Apex intelligent project creation — auto-detect project type and size, allocate agents and cron monitors by tier (small/medium/large)."
version: 1.0.0
tags: [apex, project-management, agent-allocation, cron, tiering, cli]
related_skills: [apex-cost-tracker, fleet-monitor, agent-skill-level-system]
---

# 📦 Apex 智能项目分层引擎

> 一键创建项目组 — 自动检测类型和规模，智能匹配 Agent 和巡检 Cron。

## 分层模型

```
🟢 小型(萌芽)           🟡 中型(成长)              🔴 大型(成熟)
<20文件,<3周,1人       20-100文件,1-3月,2-3人     100+文件,3+月,3+人

PM 兼任巡检              PM + 🧠智能助手            PM + 🧠智能助手
+ 1核心Agent             + 3-4核心Agent             + 5-6核心Agent
+ Git脉搏(可选)          + 5巡检Cron                + 8巡检Cron
```

### 智能助手（中大型项目自动配备）

独立的 `{project}-assistant` Profile，负责：
- 📋 任务看板扫描 (30min)
- 🎯 里程碑追踪 (每日09:00)
- ⚠️ 风险预警 (每日20:00)
- 📊 项目周报 (每周一)
- 💰 资源投入分析 (仅大型，每周一)
- 🔗 跨项目协调 (仅大型，每日14:00)

## CLI 命令

```bash
# 一键智能创建（自动检测类型和规模）
apex project create my-app --name "我的应用"

# 手动指定
apex project create dashboard --name "控制台" --type webapp --size large

# 指定项目路径（用于规模检测）
apex project create my-app --name "我的应用" --path ~/projects/my-app

# 先预览不创建
apex project create blog --name "博客" --dry-run

# 只分析不给建议
apex project analyze my-app --name "我的应用"

# 列出已注册项目
apex project list
```

## 6 种项目类型

| 类型 | 关键词 | 自动分配Agent |
|:--|:--|:--|
| `webapp` | web, dashboard, api, saas | frontend/backend/fullstack/devops |
| `ai-ml` | ai, 模型, 训练, 推理, 识别 | ai-algorithm, ai-vision, ml-engineer, data-scientist |
| `mobile` | 小程序, app, miniapp, wechat | frontend-dev, backend-dev, devops |
| `data` | data, 数据, etl, 分析, 可视化 | data-engineer, data-analyst, data-scientist |
| `content` | content, 内容, 文章, 博客, 自媒体 | content-strategist, writer, editor, publisher |
| `infra` | infra, devops, docker, k8s, 部署 | devops, ops-engineer, security-compliance |

检测优先级：名称/描述关键词 > 文件扩展名 (.wxml→mobile, .pth→ai-ml, Dockerfile→infra) > 默认 webapp

## 规模检测逻辑

基于项目目录自动分析（需 `--path` 参数）：

- `file_count >= 100` 或 `commit_count >= 500` 或 `age_weeks >= 12` → **LARGE**
- `file_count >= 20` 或 `commit_count >= 50` 或 `age_weeks >= 4` → **MEDIUM**
- 其他 → **SMALL**

无路径时默认 SMALL。

## Agent 分配矩阵

每种项目类型在 3 个规模下有不同的 Agent 配置。详见 `apex/core/project_template.py` 中的 `TYPE_CORE_AGENTS`。

PM 命名规则：取项目 key 第一个单词 + `-pm`（如 `my-app` → `my-pm`）。

## 巡检 Cron 分级

| 规模 | Cron 数量 | 包含 |
|:--|:--|:--|
| 🟢 SMALL | 0-1 | 仅 Git 脉搏（有 git 路径时） |
| 🟡 MEDIUM | 5 | PM日报 + 看板扫描 + 里程碑 + 风险预警 + 周报 |
| 🔴 LARGE | 8 | 中型全部 + 资源分析 + 跨项目协调 |

## 创建流程

1. 分析项目类型和规模
2. 展示智能分析结果（Panel）
3. 用户确认
4. 创建 PM Profile → 同步到 Hermes
5. 创建智能助手（中大型项目）
6. 创建核心 Agent Profiles
7. 注册 Cron 巡检任务
8. 输出完成报告

## 关键文件

| 文件 | 说明 |
|:--|:--|
| `apex/core/project_template.py` | 智能分层引擎 (~500行) |
| `apex/cli/main.py` | project create/analyze/list 命令 |
| `apex/interface/hermes_sync.py` | project-assistant ROLE_SOUL |

## 向后兼容

现有 4 个项目（羽球宝/Apex/FinOps/深圳地图）已注册在 `LEGACY_TEMPLATES`，不受新引擎影响。新项目用 `apex project create` 创建。
