---
name: badminton-labeling-pipeline
description: "羽毛球动作标注全流程 — 从视频采集到模型训练的完整管道操作方法。"
version: 1.0.0
load_when: "用户提到标注系统、动作标注、骨骼追踪、训练模型、badminton-label-system 相关任务时自动加载"
---

# 羽毛球动作标注流水线

> 项目路径: `~/Desktop/2026AIAPP/badminton-label-system/`
> 主项目: `~/Desktop/2026AIAPP/workspace/badminton-coach-ai/`

## 快速启动

```bash
cd ~/Desktop/2026AIAPP/badminton-label-system

# 查看状态
python scripts/amateur_pipeline.py --mode report

# 全流程 (采集→检测→标注)
python scripts/amateur_pipeline.py --mode full --count 10

# 仅采集
python scripts/amateur_pipeline.py --mode collect --count 20

# 仅检测 或 标注
python scripts/amateur_pipeline.py --mode detect
python scripts/amateur_pipeline.py --mode annotate
```

## 流水线架构

```
collect(yt-dlp) → detect(帧差法) → skeleton(MediaPipe) → annotate(28维) → parse → train
     ↓                 ↓                 ↓                    ↓              ↓
 raw_videos/        clips/        skeleton_features/   annotations/   models/
```

### Agent 清单

| Agent | 文件 | 功能 |
|:------|:-----|:-----|
| collector_agent.py | `agents/` | B站+YouTube采集, 业余/专业双轨, manifest去重 |
| detector_agent.py | `agents/` | 帧差法动作检测+片段裁剪, 参数见下方 |
| skeleton_agent.py | `agents/` | MediaPipe Pose 骨骼追踪, 15关键点→NPY |
| annotation_engine.py | `agents/` | 28维标注(关节+力学+身体+扩展), 846行 |
| annotation_extensions.py | `agents/` | 12维扩展指标(960行) |
| amateur_evaluator.py | `agents/` | 业余8维评估(300行) |
| pro_evaluator.py | `agents/` | 专业28维报告(1655行) |
| quality_checker.py | `agents/` | 基础质检(310行) |

### 编排脚本

| 脚本 | 用途 |
|:-----|:-----|
| `scripts/amateur_pipeline.py` | 业余全流程编排 |
| `scripts/pipeline.py` | 专业视频流水线 |
| `scripts/build_features.py` | 标注文本→34维特征矩阵 |
| `scripts/train_phase2.py` | GBDT/RF模型训练 |
| `scripts/qr_generator.py` | 球馆二维码生成 |
| `api_server.py` | FastAPI异步上传/评估服务 |

## 关键参数

### detector 阈值 (已校准)

```python
DETECTION_PARAMS = {
    "motion_threshold": 0.20,       # 帧差法阈值 (0.15→0.20减少误检)
    "min_frames_between_hits": 30,  # 两次击球最少间隔 (20→30避免重复)
    "clip_before_sec": 2.0,         # 击球前2秒
    "clip_after_sec": 3.0,          # 击球后3秒
    "min_clip_frames": 60,          # 最小时长2秒
    "max_clip_frames": 300,         # 最大时长10秒
}
```

调参经验: 30 clips/video 太多 → 收紧阈值到 20% + 间隔30帧 → 3-8 clips/video

### 骨骼追踪 CLI

```bash
# skeleton_agent 用位置参数不是flag!
python agents/skeleton_agent.py <video_path> [output_dir] [video_id]
# 正确:
python agents/skeleton_agent.py data/clips/clear/xxx.mp4 data/skeleton_features clear_xxx
# 错误:
python agents/skeleton_agent.py --video xxx.mp4 --output xxx  # ❌
```

### 标注引擎 CLI

```bash
# annotation_engine 也是位置参数!
python agents/annotation_engine.py <npy_path> <meta_json_path> <action_type>
# 正确:
python agents/annotation_engine.py data/skeleton_features/xxx.npy data/skeleton_features/xxx_meta.json clear_fh
# 错误:
python agents/annotation_engine.py --npy xxx.npy --output xxx.json --action clear  # ❌
```

## 特征解析

标注输出是文本格式(非JSON)，需要正则提取34维特征:

```python
from scripts.parse_features import parse_annotation

# 输入: annotation_engine 的 stdout 文本
# 输出: dict 含 A1-A6, P1-P5, B1-B2, 扩展12维

# 旧标注(104条)是dict格式的action字段
# 新标注(172条)是string格式的action字段
# build_features.py 已处理两者兼容
```

特征矩阵位于 `data/features/X_features.npy` (172×34)

## 模型训练

```bash
python scripts/train_phase2.py
```

- Phase 1: RF 71.4% (104条, 16维)
- Phase 2: GBDT 76.1% CV (172条, 34维) | 测试 91.4%
- Top5 特征: 发力链(0.124), 松弛度(0.120), 弹跳(0.118), 爆发力(0.040), 冲击力(0.040)
- 模型: `models/phase2_gradientboostingclassifier.pkl`

## 与主项目集成

主项目 `webapp.py` 已集成标注流水线API:

```python
# 路径: badminton_coach/webapp.py
# 关键代码段:
_label_root = os.path.abspath(os.path.join(
    os.path.dirname(__file__), "..", "..", "..", "badminton-label-system"))
sys.path.insert(0, _label_root)
from api_server import create_api_router
app.include_router(create_api_router())
```

端点:
- `POST /api/v1/upload` — 上传视频+异步标注
- `GET /api/v1/task/{id}` — 查询任务
- `GET /api/v1/stats` — 统计

---

## 📥 视频采集补充: P0 新类别视频下载 + 精炼动作片段提取

**背景:** 从7类扩展到23大类127子技能后，P0优先的6个新类别（发球、平抽挡、挑球、接杀防守、接发球、过渡球）缺乏训练视频。需要从YouTube中文教学频道下载并精确提取纯动作示范片段。

### 视频下载

```bash
# 资源: YouTube 中文教学频道 (刘辉羽毛球/杨晨等)
yt-dlp -f "18" --max-filesize 150M "https://youtube.com/watch?v=VIDEO_ID" -o "category/%(id)s.%(ext)s"

# 格式18 = 360p mp4 (足够MediaPipe骨骼追踪, 文件小)
# --max-filesize 150M 防止大文件占满磁盘
# 注意: yt-dlp 有时SSL重试错误, 最终100%完成, 耐心等待
```

**搜索技巧:**
```bash
yt-dlp --flat-playlist --print "%(id)s\t%(title)s" "ytsearch10:羽毛球 发球 教学 中文"
```

### 原始视频目录结构
```
data/raw_videos/
  serve/          # 发球 (7个视频, ~163MB)
  drive/          # 平抽挡 (3个视频, ~36MB)
  lob/            # 挑球 (2个视频, ~24MB)
  block/          # 接杀防守 (3个视频, ~30MB)
  serve_return/   # 接发球 (3个视频, ~37MB)
  transition/     # 过渡球 (3个视频, ~61MB)
  counter_attack/ # 防守反击 (6个视频, ~56MB) — P1
```

> ⚠️ 不要用 `--embed-thumbnail` 或 `--embed-metadata`, 保持最小依赖

### 精炼动作片段提取 (v2 Pipeline)

**脚本:** `scripts/p0_pipeline_v2.py`

**策略:** 结合ffmpeg低阈值场景检测 + 音频静音检测, 精准定位"讲解→示范"边界

**关键参数调优过程:**
- v1错误: `SCENE_THRESHOLD = 0.35` → 整个视频被当做一个clip (695s未切割)
- v2修复: `SCENE_THRESHOLD = 0.15` + 音频静音检测 `-30dB / 0.5s`

**核心算法:**
1. ffmpeg场景检测 → 获取画面切换的时间点（帧差法，阈值0.15）
2. ffmpeg音频静音检测 → 获取"讲解停顿"的时间点（静音=说话停止，动作开始）
3. 合并边界去重 + 过滤 < 3s 的微片段
4. 分类: 3-60s = `action_demo` ✅ (目标片段); 60-180s = `talking` (保留上下文)
5. Whisper `tiny` 模型只跑前300s音频（避免整段大视频转写数十分钟）
6. 保存: 动作片段→`processed_videos/`; 转录文本→`transcripts/`

**运行方式:**
```bash
cd ~/Desktop/2026AIAPP/badminton-label-system
# 后台运行(总处理时长约5-30分钟, 取决于视频数量)
python3 scripts/p0_pipeline_v2.py &
```

**输出验证:**
```bash
# 统计各类别的动作片段
for d in data/processed_videos/*/; do echo "$d: $(find "$d" -name '*.mp4' | wc -l) clips"; done
# 检查转录文本
ls -la data/transcripts/*.txt
# 查看摘要
cat data/processed_videos/p0_v2_summary.json | python3 -m json.tool | head -40
```

### 管道架构对比 (旧 vs 新)

| 方面 | 旧管道 (detector_agent.py) | 新Pipeline (p0_pipeline_v2.py) |
|:----|:--------------------------|:-------------------------------|
| 输入源 | 已下载视频(任意) | YouTube中文教学(精准搜索) |
| 检测方法 | 帧差法 motion_threshold=0.20 | ffmpeg场景检测0.15 + 音频静音 |
| 目标片段 | 3-8 clips/视频, 每clip 2-10s | 3-10 clips/视频, 每clip 3-60s |
| 片段类型 | 击球瞬间周围 | 完整动作示范段落 |
| 转录 | 无 | Whisper tiny zh (前300s) |
| 运行时间 | 快(1-2min/视频) | 中等(3-8min/视频, 含Whisper) |

### ⚠️ 已知问题

- **yt-dlp SSL错误/重试:** 国内网络不稳定, 重试3-5次最终100%成功, 需要耐心（非代码bug）
- **Whisper tiny中文精度:** 对羽毛球术语识别一般, 但作为"讲解内容留存"够用
- **大视频文件:** 反手发平高球113MB/3300s → 提取前300s音频转写, 其余跳过
- **B站视频需cookies:** 目前使用YouTube中文教学替代

---

## 已知问题 & 解决方案

### B站下载
- Chrome cookies 仍超时 → 需要代理或手动提供cookies文件
- 替代: 用已有的 130 个教学视频(7类)可突破 200 标注

### 等级标签不平衡
- L1 仅1样本, L2 仅12样本 → 当前模型只训练 L3-L6 四分类
- 需要更多业余初学者数据

### Python 环境
- 标注系统用系统 Python 3.9 (`/Library/Developer/CommandLineTools/usr/bin/python3`)
- 主项目用 Hermes venv Python 3.11 (`~/.hermes/hermes-agent/venv/bin/python3`)
- sklearn 装在系统 Python user site-packages

## 数据统计 (当前)

| 指标 | 数值 |
|:-----|:---:|
| 原始视频 | 130 + 27 个 (7+6=13类) |
| — 旧7类 | 130个 (高远/吊球/杀球/网前/步法/平抽/防守) |
| — 新P0 | 21个 (发球/平抽挡/挑球/接杀防守/接发球/过渡球) |
| — 新P1 | 6个 (防守反击) |
| 动作片段 | 172 (旧) + ~147 (新P0, v1提取) / 待v2重跑 |
| 骨骼追踪 | 197 个 NPY |
| 总标注 | 276 条 |
| 有效特征 | 172×34 |
