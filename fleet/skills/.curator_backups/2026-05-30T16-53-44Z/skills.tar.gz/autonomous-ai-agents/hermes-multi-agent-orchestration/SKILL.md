---
name: hermes-multi-agent-orchestration
description: "Set up and manage a multi-agent team using Hermes Profiles + Kanban + SOUL.md personas. Covers profile creation, soul injection, Kanban board init, task dispatch, and multi-profile coordination for parallel workstreams."
version: 1.0.0
author: Luke & 小卢
platforms: [macos, linux]
---

# Hermes Multi-Agent Orchestration

Orchestrate a team of AI agents using Hermes's built-in Profile system, Kanban board, and SOUL.md personality files. Each agent is a fully independent Hermes instance with its own config, memory, skills, and tool access — all coordinated by a central orchestrator (you).

## When to use

- User has a complex multi-domain project (e.g. product dev + content + operations + fundraising)
- User wants specialized agents handling different concerns in parallel
- User wants a "CEO + project manager + team" dynamic rather than one agent doing everything
- User explicitly asks for an "AI team" or "fleet" or "multi-agent setup"

## Architecture

```
                    👑 CEO / Product Owner (human)
                          │
              ┌───────────┴───────────┐
              │     Orchestrator      │
              │  (your/hermes session) │
              └───────────┬───────────┘
                          │
    ┌─────────┬─────────┬┴┬─────────┬──────────┐
    │         │         │ │         │          │
  💻开发线    🤖AI线    │ 📢商业线  🔒合规线   💰资本线
 Frontend    Vision    Content    Security   Fundraising
 Ops         Algorithm Marketing  Legal      Pitch/Deck
```

## Step 0 — Discover Available Profiles

Before planning your team structure, check what profiles already exist:

```bash
hermes profile list
```

Sample output:
```
Profile          Model                        Gateway      Alias
───────────────    ───────────────────────────    ───────────    ──────────────
◆default         deepseek-chat                running      —
 ai-algorithm    —                            stopped      ai-algorithm
 ai-vision       —                            stopped      ai-vision
 architect       —                            stopped      architect
 frontend-dev    —                            stopped      frontend-dev
 ops-engineer    —                            stopped      ops-engineer
```

This tells you:
- Which profiles exist (so you don't need to create new ones)
- Whether their Gateway is running (stopped = no agent working — the default profile's Gateway handles kanban dispatching)
- Whether they have a CLI alias (e.g. `frontend-dev chat` works at the terminal)

To see a profile's full identity definition:

```bash
cat ~/.hermes/profiles/<name>/SOUL.md
```

To see what model it would use:

```bash
hermes profile show <name>
```

### Key observation: profiles have SOUL.md but NO config

The `hermes profile create` command creates a SOUL.md (personality) but does NOT create `config.yaml` or `.env`. Every profile needs both before it can do any work. See "Batch Profile Configuration" below.

## Step 1 — Create a Profile (if needed)

This creates:
- `~/.hermes/profiles/<name>/` — profile home directory
- A CLI wrapper at `~/.local/bin/<name>` — run like `frontend-dev chat`
- 89 bundled skills synced automatically

## Step 2 — Inject SOUL.md (personality)

Each profile gets a `SOUL.md` that defines its identity, personality, tech stack, core skills, and working principles.

**Minimal SOUL.md template:**

```markdown
# 👤 Role Name — Brief Description

## Identity
Who this agent is and what department they belong to.

## Personality
3-4 traits that define how they communicate and work.

## Tech Stack
Languages, frameworks, tools this agent uses.

## Core Skills
1. Concrete skill one
2. Concrete skill two
3. Concrete skill three

## Working Principles
1. First principle
2. Second principle
```

Write it to `~/.hermes/profiles/<name>/SOUL.md` with `write_file`.

## Step 3 — Initialize Kanban Board

```bash
hermes kanban init
```

This creates `~/.hermes/kanban.db` — the shared task queue.

## Step 4 — Dispatch Tasks via Kanban

The orchestrator (your main session) creates tasks on the Kanban:

```bash
hermes kanban create --title "Build X feature" --assignee frontend-dev --description "..."
hermes kanban create --title "Design Y algorithm" --assignee ai-vision --description "..."
```

Agents pick up their tasks when they run and check the board.

## Step 5 — Run Agents in Parallel

```bash
# Fire-and-forget agents in background
terminal(command="frontend-dev chat -q 'Build the checkin timeline page'", background=true, notify_on_complete=true)
terminal(command="ai-vision chat -q 'Design photo recognition pipeline'", background=true, notify_on_complete=true)

# Orchestrator can also use delegate_task for managed subagents
```

## P0 Roles (start here)

| Role | Profile Name | Why First |
|------|-------------|-----------|
| Frontend Developer | `frontend-dev` | UI/UX work, app pages |
| Vision/AI Engineer | `ai-vision` | Image recognition, video analysis |
| Architect | `architect` | System design, DB schema, scalability |

## P1 Roles

| Role | Profile Name | Why |
|------|-------------|-----|
| Algorithm Engineer | `ai-algorithm` | Recommendation engine, user profiling |
| Content/Marketing | `content-marketing` | Blog, social media, brand voice |
| Security/Compliance | `security-compliance` | Privacy policy, data protection, audits |
| Ops Engineer | `ops-engineer` | Deployment, nginx, monitoring, CI/CD |

## P2 Roles

| Role | Profile Name | Why |
|------|-------------|-----|
| Fundraising/Pitch | `fundraising-pitch` | BP, financial models, investor decks |
| Decision Analyst | `decision-analyst` | Market research, data-driven decisions |

## Model Cost Strategy

| Task Type | Recommended Model | Est. Monthly Cost |
|-----------|------------------|-------------------|
| 🟢 Simple coding, chat | DeepSeek (used in session) | ~5-15 RMB |
| 🟡 Complex reasoning, architecture | Claude Sonnet | ~50-100 RMB |
| 🔴 Vision, video analysis | Claude/GPT-4V | ~100-300 RMB |
| ⚪ Local tasks, cron scripts | Local LLM (free) | 0 RMB |

## Batch Profile Configuration

Newly-created profiles have no `config.yaml` or `.env` — you must create them. Do it programmatically for many profiles at once:

```python
import os
from hermes_tools import write_file

profiles = ["ai-algorithm", "ai-vision", "architect", "frontend-dev", ...]
base_dir = "/Users/Mac/.hermes/profiles"

# Read API key from main profile's .env
r = terminal("grep DEEPSEEK_API_KEY /Users/Mac/.hermes/.env | head -1")
api_key = r["output"].strip().split("=", 1)[1].strip()

config = """model:
  default: deepseek-chat
  provider: deepseek
  base_url: https://api.deepseek.com/v1
providers:
  deepseek:
    base_url: https://api.deepseek.com/v1
agent:
  max_turns: 30
"""

for p in profiles:
    write_file(path=f"{base_dir}/{p}/config.yaml", content=config)
    write_file(path=f"{base_dir}/{p}/.env", content=f"DEEPSEEK_API_KEY={api_key}\n")
```

**Profile skills**: profiles inherit 89+ bundled skills automatically. The `skills/` subdirectory exists and is populated on `hermes profile create`.

**yuji-pm special case**: the PM profile should include `kanban.board: yuji` (or whatever board name) in its config.yaml so its dispatcher targets the right board.

## Kanban Swarm Mode (Parallel Workers → Verifier → Synthesizer)

The `hermes kanban swarm` command creates a complete parallel-processing task graph in one call:

```bash
hermes kanban swarm \
  --worker "frontend-dev:Task title 1:skill1,skill2" \
  --worker "ai-vision:Task title 2" \
  --worker "ops-engineer:Task title 3" \
  --verifier architect \
  --synthesizer yuji-pm \
  --priority 1 \
  --json \
  "Swarm goal description"
```

**How it works:**
1. Creates N parallel worker tasks (one per `--worker`), all immediately `ready`
2. Creates a verifier task with all workers as parents → starts after all workers complete
3. Creates a synthesizer task with the verifier as parent → starts after verification
4. The default Gateway's embedded dispatcher picks up `ready` tasks every 60 seconds

**Priority is an integer** (1, 2, 3...), NOT a string like "P0". `--priority P0` will error.

**JSON output** returns the task IDs:
```json
{
  "root_id": "t_abcdef01",
  "worker_ids": ["t_11111111", "t_22222222", "t_33333333"],
  "verifier_id": "t_44444444",
  "synthesizer_id": "t_55555555"
}
```

You can inspect the full graph with `hermes kanban list`.

## Cleanup Before First Real Use

When re-purposing an existing Kanban board that has old/completed tasks:

```bash
# Archive everything — the board has no "purge" command
hermes kanban list --archived  # see all tasks including archived
hermes kanban archive <task_id>  # archive one by one, or loop:
for tid in t_xxx t_yyy t_zzz; do hermes kanban archive $tid; done
```

Archived tasks stay in the DB for audit but don't show in default list views.

## Pitfalls

1. **Each new profile has no API keys or config.** Profiles created via `hermes profile create` have only a SOUL.md and empty directories. You MUST create `config.yaml` + `.env` for every profile before it can do work. Use the batch pattern above.
2. **Kanban dispatcher runs inside the Gateway.** The standalone `hermes kanban daemon` is deprecated — tasks are dispatched by the default profile's Gateway. Start it with `hermes gateway start`. The default profile must be running as the scheduler; if the default Gateway is stopped, tasks sit in 'ready' forever.
3. **Parallel profile sessions burn tokens faster.** DeepSeek is cheap (~0.5 RMB/million tokens), Claude is not. Budget accordingly.
4. **`delegate_task` max_concurrent_children defaults to 3.** For larger parallel bursts, increase `delegation.max_concurrent_children` in config.yaml, or spawn background `hermes chat -q` processes via terminal.
5. **Profile context isolation:** each profile has its own session DB and memory. Cross-agent context must be shared via the filesystem (shared project directory) or Kanban task descriptions.
6. **`project.config.json` miniprogramRoot gotcha with CLI.** If using `--project ./miniprogram` (pointing directly at the miniprogram dir), do NOT include `miniprogramRoot` in project.config.json — it causes "请检查 project.config.json 是否存在及是否有效 (code 19)". For GUI use, keep `miniprogramRoot` in a root-level config and open the parent directory.

## Verification

```bash
hermes profile list
hermes kanban list
# Test a specific profile:
frontend-dev chat -q 'What is my role and project directory?'
```
