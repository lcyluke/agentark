---
name: badminton-coach-ai
description: Build or extend a badminton motion-analysis AI coach — pose estimation, stroke detection, footwork analysis, pro-comparison scoring, video scraping, and LLM coaching critique. Use when the user wants sports video analysis (badminton specifically), automatic technique diagnosis, training plan generation, or wants to iterate on the existing project at /Users/Mac/workspace/badminton-coach-ai.
---

# Badminton Coach AI

End-to-end pipeline: video → pose estimation → stroke detection → technique
diagnosis → footwork analysis → pro comparison → LLM coaching critique →
annotated output video.

Project location: `/Users/Mac/Desktop/2026AIAPP/workspace/badminton-coach-ai`

**Brand name:** 羽球宝AI搭子 (NOT 羽迹, NOT 羽毛球AI教练 — this is the actual WeChat mini-program registered name used for 备案.)

## When to use

- User wants to analyze badminton (or similar racket sport) technique from video
- Iterate/extend the existing badminton-coach-ai project
- Build sports motion analysis with MediaPipe Pose
- **User asks about the 三等级付费系统** (free/amateur/pro tiers, booking, assessment history — see references/backend-api-routes.md for the API route map)
- **User asks for PRD or product requirements** for the badminton coach app — see references/prd.md in the skill dir
- **User says "持续迭代", "持续开发", or asks for multi-sprint development** — this is a continuous iteration project with 5h/week budget, single-developer, self-funded. See the "Continuous iteration mode" section below for the session-resume checklist and sprint cadence.

## Architecture (modules under badminton_coach/)

| Module | Role |
|--------|------|
| `pose_estimator.py` | MediaPipe PoseLandmarker → 33 keypoints/frame as `FramePose` (new v0.10.35 API) |
| `stroke_analyzer.py` | Wrist-speed peak detection → stroke classify + 4 metrics |
| `footwork_analyzer.py` | split-step, recovery, court coverage, stance height |
| `reference_library.py` | Pro benchmark fingerprints + 0–100 similarity scoring |
| `skill_grader.py` | L1~L7 amateur grade + 6-dim radar profile + per-action scoring |
| `image_assessor.py` | Single-frame photo → pseudo-StrokeEvent → grade (low conf) |
| `coach.py` | Rule report + pro comparison + LLM critique (auto-fallback) |
| `visualizer.py` | Skeleton overlay + stroke annotation video |
| `webapp.py` | FastAPI: /api/assess, /api/doubles (双打角色), /api/full, / (Web UI) |
| `auth_api.py` | Auth + 三等级付费系统 (user tiers, bookings, history) |
| `double_analyzer.py` | Doubles role diagnosis (4 roles: 网前雨刮器/后场重炮型/全场跑动型/防守反击型) + compatibility S/A/B/C matrix + dual-mode API (single/double) via `/api/doubles?mode=single|double` |

Backend API route map: see `references/backend-api-routes.md`.
Check-in API routes: see `references/checkin-api-routes.md` (7 endpoints, all Bearer auth).
DevTools CLI workflow: see `references/wechat-devtools-cli.md`.
WeChat Mini-Program scaffold: see `references/wechat-miniprogram-scaffold.md` (12 pages: login, survey, home, assess, result, training, injury, gear, profile, guide, booking, history).
Tech architecture decision guide: see `references/tech-architecture-decision.md`.

KEY: `auth_api.py` uses `APIRouter(prefix="/api")`, so auth endpoints are
`/api/auth/wechat`, `/api/auth/sms/send`, `/api/auth/sms/login` — NOT
`/api/sms/send` etc. Grep the decorators before calling; guessing cost two 404s.

## Skill grading system (L1~L7)

7-tier amateur scale aligned to 中羽协段位 / D-C-B-A-S / NTRP. Key design:
- 6 dims: swing_power, lower_body, footwork, recovery, balance, consistency
- L3 (中级) hard gate: swing>=45 AND lower>=30 AND footwork>=35, else capped at L2
- consistency is a multiplier (0.75+0.25*c) to prevent single-rally inflation
- image source → low confidence (0.45), video with >=8 strokes → 0.85

## Setup

```bash
cd /Users/Mac/Desktop/2026AIAPP/workspace/badminton-coach-ai
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
# MediaPipe 0.10.35+ requires downloading the pose model separately:
curl -L -o pose_landmarker_lite.task \
  "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task"
```

## Operation

### Start backend

```bash
cd /Users/Mac/Desktop/2026AIAPP/workspace/badminton-coach-ai
source venv/bin/activate

# CRITICAL: Kill any stale process on port 8000 first (common resume gotcha)
lsof -ti:8000 | xargs kill -9 2>/dev/null; sleep 1

export BADMINTON_SECRET="$(openssl rand -hex 32)"
python3 -c "
import uvicorn
uvicorn.run('badminton_coach.webapp:app', host='127.0.0.1', port=8000, log_level='info')
"
```

### Start backend — CRITICAL: use venv Python, NOT system Python

The project's MediaPipe was built with venv's Python 3.11 + NumPy 1.x.
System Python (e.g. `/opt/anaconda3/bin/python3`) runs NumPy 2.x which crashes
MediaPipe with `ImportError: numpy.core.multiarray failed to import`.

Always start the backend using the VENV python binary directly:

```bash
cd /Users/Mac/Desktop/2026AIAPP/workspace/badminton-coach-ai
lsof -ti:8000 | xargs kill -9 2>/dev/null; sleep 1
./venv/bin/python3 -m uvicorn badminton_coach.webapp:app --host 127.0.0.1 --port 8000 --log-level info
```

**Do NOT use** `source venv/bin/activate && python3 -c "uvicorn.run(...)"` —
the `python3` inside the `-c` block may resolve to `/opt/anaconda3/bin/python3`
rather than the venv's python, triggering the NumPy version conflict.
Using `./venv/bin/python3 -m uvicorn ...` ensures the venv binary is used
at both the process and the import level.

If you accidentally start with system Python and get "initialization failed"
on `/api/assess`, check the backend logs for `numpy.core.multiarray failed to import`.
Kill the process and restart with `./venv/bin/python3 -m uvicorn ...`.

### Start-of-session health check (resume checklist)

When resuming work on this project after a break (especially when the user says "继续" or starts a new message asking to continue development), run this checklist BEFORE doing anything else:

1. **Backend alive?** `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8000/` — if not 200, start it (see above). If port busy, `lsof -ti:8000 | xargs kill -9 2>/dev/null; sleep 1` to kill stale process first.
2. **DevTools running?** `pgrep -fl wechatwebdevtools` — if no, open with: `/Applications/wechatwebdevtools.app/Contents/MacOS/cli auto --project miniprogram/` (but first quit stale daemon: `cli quit 2>/dev/null; pkill -f wechatwebdevtools 2>/dev/null; sleep 2`)
3. **Git clean?** `git status --short` — uncommitted changes are expected during iteration, but note them for the next commit/tag.
4. **Quick API smoke test:** `curl -s http://127.0.0.1:8000/api/spec | head -c 100`
5. **Survey question count check:** `curl -s http://127.0.0.1:8000/api/survey/questions | python3 -c "import json,sys; d=json.load(sys.stdin); print(len(d['questions']) if isinstance(d,dict) and 'questions' in d else len(d) if isinstance(d,list) else 'warn: unknown format')"` — should be 5. If 1, the router prefix may have changed (auth_api.py uses APIRouter with prefix).
6. **Report status to user** in a compact table: backend ✅/❌, DevTools ✅/❌, git state, API health.

### Continuous iteration mode (5h/week · single dev · self-funded)

When the user says "持续迭代", "持续开发", "继续", or initiates a session asking to resume development, follow this sprint cadence:

1. **Session resume**: run the health check checklist above. Report compact status.
2. **Prioritize**: the user's implicit preferences (confirmed across sessions) are: fix known bugs > UI/UX fixes > backend features > deployment > new capabilities. Never propose new features if there are known bugs.
3. **Produce increments**: every session should produce at least one working increment. No session is "just planning" unless the user explicitly asks for it.
4. **Version bumps**: `v0.1` → `v0.2` → ... → `v0.6` (deploy+release). Tag each version with `git tag -a v0.X.0 -m "..."` after passing UAT.
5. **UAT before tag**: run the 12-step smoke test (see `references/backend-api-routes.md`) covering changed endpoints. If all pass, tag.
6. **Notify on version**: when a version is tagged and backend restarted, tell the user "v0.X ready. Summary: <3 bullets>". Offer to compile DevTools for manual testing.
7. **Backlog tracking**: keep sprint items in todo() — max 3 active items. Move completed to memory as a "latest version v0.X" note, not full task logs.

## CRITICAL PITFALLS (learned the hard way)

### MediaPipe & AI Pipeline

1. **MediaPipe 0.10.35+ dropped `mp.solutions` API.** The `mp.solutions.pose.Pose` API is REMOVED in MediaPipe 0.10.35+. Migrate to `mediapipe.tasks.python.vision.PoseLandmarker` with a downloaded `.task` model file. Full migration guide:

   **Download the model:**
   ```bash
   curl -L -o pose_landmarker_lite.task \
     "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task"
   ```

   **Old code (removed):**
   ```python
   with mp.solutions.pose.Pose(static_image_mode=True, model_complexity=1) as pose:
       res = pose.process(rgb)
       lm = res.pose_landmarks.landmark  # 33 landmarks
   ```

   **New code (PoseLandmarker):**
   ```python
   from mediapipe.tasks.python import vision
   from mediapipe.tasks.python.core.base_options import BaseOptions
   
   options = vision.PoseLandmarkerOptions(
       base_options=BaseOptions(model_asset_path="pose_landmarker_lite.task"),
       running_mode=vision.RunningMode.IMAGE,  # or .VIDEO
       min_pose_detection_confidence=0.4,
   )
   detector = vision.PoseLandmarker.create_from_options(options)
   mp_img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
   result = detector.detect(mp_img)
   lm = result.pose_landmarks[0]  # list of persons, each with 33 landmarks
   lm[0].x  # or use the old accessor pattern
   ```

   **Key differences:**
   - Model file: `.task` (5.6MB), not built-in
   - Input: `mp.Image`, not raw numpy/rgb
   - No `with` context manager — create `detector` once, reuse
   - Keypoints: `result.pose_landmarks[person_idx][kpt_idx]` not `result.pose_landmarks.landmark[kpt_idx]`
   - No `.visibility` field on landmarks — set to `1.0` by default
   - For video: `running_mode=vision.RunningMode.VIDEO`, use `detector.detect_for_video(mp_img, timestamp_ms)` with timestamp in milliseconds
   - Multi-person: returns all detected people as list; also add `num_poses=N` to options to set max
   - Single-person photos still mostly work, but partially occluded second people are often missed — use the "遮罩法" (mask out first person region and re-detect) to recover

   **Files that needed migration in this project (all done):**
   - `double_analyzer.py` — `_detect_two_people()` and `_get_detector()`
   - `pose_estimator.py` — `PoseEstimator._lazy_init()` and `process_video()`
   - `image_assessor.py` — `_frame_from_image()`
   - `webapp.py` — `_assess_image()` (standalone copy for the doubles tab)

2. **MediaPipe Pose is SINGLE-PERSON, CLOSE-UP only.** Wide-angle broadcast / multi-player gym footage gives near-zero detection and garbage metrics. For broadcast footage you need YOLOv8-pose (multi-person) — that's an upgrade path, not a bug.

3. **YouTube is fully bot-walled.** `player_client: [android, ios, web]` alone does NOT bypass it. Use archive.org for real badminton footage: `curl -s "https://archive.org/advancedsearch.php?q=badminton+AND+mediatype:movies&fl[]=identifier&fl[]=title&rows=8&output=json"`

4. **Stroke peak detection**: use adaptive "global threshold + local prominence" (peak >= 2x local median). Already implemented in stroke_analyzer.py — don't regress it.

5. **Quick pipeline-validation video without user footage.** Intel-iot-devkit has a directly-downloadable clip: `curl -sL -o test_human.mp4 "https://github.com/intel-iot-devkit/sample-videos/raw/master/person-bicycle-car-detection.mp4"`. Proves pose detection fires on real humans. Synthetic stick-figure video from `cli demo` will NEVER be detected by MediaPipe (0 frames hit) — that is expected, demo only validates video read/write plumbing.

### FastAPI Backend

10. **FastAPI Header(None) + GET query params = 422.** When same endpoint has BOTH query params AND `authorization: str = Header(None)`, FastAPI's `Header()` inject triggers the `query` location for `authorization`, producing 422 on every request. Fix: use `request: Request` and extract manually: `request.headers.get("Authorization") or request.headers.get("authorization")`. This is REQUIRED for all GET endpoints with query params that need auth. POST endpoints with `Form()` params are safe — `Form()` pins the data source, so `Header(None)` works there.

11. **venue_db.py CSV path fallback chain.** `VENUE_CSV` env var → hardcoded `~/Desktop/2026AIAPP/shenzhen-badminton/data/venues.csv` → `../data/venues.csv`. If running from a subdirectory the paths may miss. Set `export VENUE_CSV=/absolute/path/venues.csv` to override. The module caches after first load — if the file moves, clear the cache or restart.

### WeChat Mini-Program

12. **WeChat mini-program structure**: lives at `miniprogram/` with **12 pages**: login, survey, home, assess, result, training, injury, gear, profile, guide, booking (预约陪练), history (评估历史).

12a. **Production deployment prerequisites (user must do themselves):** (a) register at mp.weixin.qq.com → get AppID/AppSecret; (b) get ICP-备案 HTTPS domain for backend; (c) sign up for SMS provider. Backend has Mock fallback — works in devtools without real credentials. Production deploy bottleneck is ICP 备案 (7-15 days) — file it FIRST since it gates HTTPS whitelist.

12b. **DevTools auto-open with real AppID.** The CLI open command works reliably when a real AppID is set in `project.config.json`:
   ```bash
   /Applications/wechatwebdevtools.app/Contents/MacOS/cli auto --project <miniprogram_dir>
   ```
   Without a real AppID, `open` fails with "AppID 不合法". The `auto` command starts the IDE, loads the project, and starts automation mode. User's actual AppID: `wxdad7cddb0cfa785e` (羽球宝AI搭子).

13. **No real payments**: gear recommendation is search-URL jumps only. Real 微信支付 requires business license — explicitly OUT OF SCOPE.

14. **WeChat mini-program API error handling — `e.message` is often undefined.** WeChat's request utility returns `{msg: "...", code: ...}` NOT JavaScript `Error` instances. Fix:
    ```javascript
    } catch (e) { this.setData({ err: e.message || e.msg || '请求失败' }); }
    ```
    Fix api.js request wrapper too:
    ```javascript
    if (res.statusCode >= 400) return reject(new Error(
      (res.data && (res.data.detail || res.data.msg || res.data.error)) || '请求失败'
    ));
    ```

15. **WeChat mini-program login — WeChat-only (no SMS).** Files: `pages/login/login.wxml` (single button), `pages/login/login.js` (only `loginWechat` + `_afterLogin`). `app.js` `apiBase` must be `http://43.139.191.202` (HTTP before ICP 备案, HTTPS after). DevTools: details → local settings → ☑ 不校验合法域名.

16. **WeChat devtools `@babel/runtime` / enhance mode packaging bug.** Error: `module '@babel/runtime/helpers/typeof.js' is not defined` at `login.js:4`. Fix in `project.config.json`: `"libVersion": "2.33.0"`, `"enhance": false`, remove `lazyCodeLoading` from root. In `app.json`: remove `lazyCodeLoading` from JSON root. DevTools → details → 本地设置 → 基础库选 2.33.0 (not gray 3.16.1). Close devtools, `rm -rf ~/Library/Application\ Support/WechatDevtools/*/Default/`, reopen and recompile.

17. **WeChat mini-program 备案 (Tencent platform).** Just AppID + AppSecret (no APK MD5, no APK needed). APK signing MD5 is only for Android APK distribution — irrelevant for WeChat mini-program.

18. **WeChat devtools "app.json is not found in project root".** Devtools reads the `project.config.json` from the `--project <dir>` passed to the CLI. If that dir has a `project.config.json` with `miniprogramRoot` pointing to a subdirectory, DevTools looks for `app.json` under the subdirectory. **If using `--project` pointing directly at the miniprogram directory, do NOT include `miniprogramRoot`** — it produces "请检查 project.config.json 是否存在及是否有效 (code 19)". Use one of these patterns:
    - Pattern A (recommended for CLI): `--project ./miniprogram` with `project.config.json` at `./miniprogram/project.config.json`, no `miniprogramRoot` field.
    - Pattern B (recommended for GUI): root `project.config.json` with `"miniprogramRoot": "miniprogram/"`, then open the ROOT dir in the IDE.

19. **WeChat devtools CLI port must be manually enabled once.** CLI commands fail with "IDE service port disabled" until user opens DevTools → Settings → Security Settings → enables Service Port. Requires WeChat scan confirmation. One-time setup; persists across restarts.

### Tencent Cloud / Server Deployment

20. **TencentOS nginx.conf does not include sites-enabled.** Only `include /etc/nginx/conf.d/*.conf` — no `sites-enabled/` include. Write config to `conf.d/` directly. Remove `default_server` from listen directives (nginx.conf:39 already has one, else "duplicate default server"). Tencent Cloud Security Group (cloud console) is a SEPARATE firewall — open 80/443 there too or external requests are blocked before reaching nginx.

21. **Python 3.11 missing _sqlite3 module on TencentOS.** Causes badminton.service to fail and enter auto-restart loop. Fix:
    ```bash
    yum install -y sqlite-devel
    cd /tmp/Python-3.11.9
    ./configure --enable-optimizations --prefix=/usr/local --with-sqlite3
    make -j$(nproc) && make altinstall
    rm -rf /data/badminton/app/venv
    /usr/local/bin/python3.11 -m venv /data/badminton/app/venv
    /data/badminton/app/venv/bin/pip install -r requirements.txt
    ```

22. **deploy.sh script evolution.** V1: apt-get → "command not found" → detect yum vs apt-get. V2: sudo PATH truncation → python3.11 not found. V3: for-loop hardcoded paths + rm -rf venv + pip force official PyPI. V4: Tencent Cloud pip `/etc/pip.conf` global lock → PIP_CONFIG_FILE override. V5: pip.conf trusted-host two lines → "option already exists" → merge to one line. V6: trusted-host one line + sqlite3 detection + auto-fix compile. V7: mkdir /etc/nginx/sites-available + conf.d write + remove duplicate default_server. Final: includes sqlite-devel, python3.11 hardcoded path, pip.conf override, nginx conf.d write. Re-rsync after each patch; `rm -rf /data/badminton/app/venv` if re-running.

23. **Tencent Cloud pip internal mirror lock.** Tencent Cloud yum repos mirror pip packages with restricted version range (max numpy 1.19.5). Fix: `PIP_CONFIG_FILE=/data/badminton/pip.conf` pointing to `https://pypi.org/simple/` with `trusted-host = pypi.org files.pythonhosted.org` (one line, not two).

24. **Heavy pip installs look frozen but are running.** `-q` hides all output. Check progress with `ls /data/badminton/app/venv/lib/python3.11/site-packages/ | wc -l`. Allow 2-5 min. Always remove `-q` during debugging so progress is visible.

25. **Tencent Cloud SMS real integration.** Module `sms_tencent.py` wired into `_send_sms()` when `SMS_PROVIDER=tencent`. Needs env: TENCENT_SECRET_ID/KEY, SMS_SDK_APPID (1400xxxxxx), SMS_SIGN_NAME, SMS_TEMPLATE_ID. Both signature AND template need Tencent approval.

26. **云片 (Yunpian) SMS — 个人可用的短信平台.** Supports individual registration with ID card auth. `_send_sms()` uses `SMS_PROVIDER=yunpian` to switch. HTTP 400 `code:-62 "无效资质信息"` = developer info not filled in (account settings, takes hours~1 day to verify). Test: `YUNPIAN_APIKEY=xxx SMS_SIGN_NAME=羽球宝 python deploy/test_sms.py <phone>`.

## Verification workflow (always do this)

```bash
source venv/bin/activate
python -m badminton_coach.cli selftest   # synthetic keypoints, no video/net
python -m badminton_coach.cli demo       # synthetic video, full pipeline
# real video:
python -m badminton_coach.cli analyze <video.mp4> --output out.mp4 --no-llm
```

`selftest` synthesizes two stroke trajectories (one clean smash, one flawed)
and asserts stroke detection + footwork + comparison + plan all fire. This is
the fast regression gate — run it after any edit to the analysis engine.

Quick API smoke test (no video needed): upload the 6 test images and compare
results against `references/ai-assessment-test-images.md`. The `lower_body`
dimension should consistently be the lowest across all scorable images.

For a **structured 6-step UAT** that covers login → survey → assess × 6 → doubles →
full pipeline → tier check + history, see the "Structured UAT testing pattern"
section in `references/backend-api-routes.md`. This is the standard regression
test to run before every version tag.

### UAT Run Pattern: auto baseline first, then human judgment

When the user asks to do UAT testing (especially with WeChat mini-programs):

1. **Run the automated UAT smoke test FIRST** (the 6-step pattern in `references/backend-api-routes.md`). This gives you a baseline: login → survey → assess × 6 → doubles → full → tier check.
2. **Parse and interpret the results into a human-readable table** — grade per image, strengths/weaknesses per dimension, doubles role, training plan summary.
3. **Compile the mini-program AND generate a phone-scan preview QR** in one shot using the DevTools CLI workflow below. Send the QR to the user via `MEDIA:`.
4. **Present the user with specific questions**: "扫这个码在手机上跑一遍登录→评估，看看AI诊断准不准？尤其图4说你'站着扣杀'挥拍57分但下肢仅14分，这个符合你的感觉吗？"
5. **If automated tests identified any actual bugs** (not just parser errors), fix them BEFORE asking the user to scan. Don't make the user find bugs you could have caught automatically.
6. **On user feedback** — if they confirm the diagnosis matches their real experience, that's PASS. If they disagree, note the delta as product feedback for model improvement.
7. **Collect UX/copy feedback on the spot** — the user may flag awkward wording (e.g. "AI帮我" → "我帮你"). Fix it immediately: patch `auth_api.py`'s `SURVEY_QUESTIONS` list for backend-served text AND `survey.wxml`'s static text → restart backend → recompile → regenerate preview QR. Don't defer copy fixes to the next sprint — they take 2 minutes and closing the loop in the same session builds trust.

**Key insight**: the automated UAT catches regression bugs (server crash, 422, 500, missing endpoints, wrong field names). The human UAT catches model quality issues (wrong grade, irrelevant training plan) AND UX/copy issues (awkward wording, confusing UI text). Both are needed, but run automated first so the user only does the high-value judgment work.

### DevTools CLI compile-preview workflow

After backend is up and any code changes made, compile and generate a phone-scan preview:

```bash
CLI="/Applications/wechatwebdevtools.app/Contents/MacOS/cli"
PROJ="/Users/Mac/Desktop/2026AIAPP/workspace/badminton-coach-ai/miniprogram"
mkdir -p /tmp/wechat_qr

# 1. Clean restart (quit stale session first)
"$CLI" quit 2>/dev/null
pkill -f wechatwebdevtools 2>/dev/null
sleep 3  # wait for full teardown

# 2. Compile (auto = open + load + compile)
"$CLI" auto --project "$PROJ"

# 3. Generate preview QR — always use --qr-format image + --qr-output
#    The terminal QR code (default) often generates before project is ready.
"$CLI" preview --project "$PROJ" --qr-format image --qr-output /tmp/wechat_qr/preview.png

# 4. Send QR to user
# MEDIA:/tmp/wechat_qr/preview.png
```

**IMPORTANT preview pitfalls:**
- `--qr-format terminal` (default) produces ASCII art that scans poorly. Always use `--qr-format image --qr-output /path`
- If you get error 10 "二维码输出路径无效或不存在", the `--project` path is wrong or project.config.json is invalid
- If you get error 19 "请检查 project.config.json", see pitfall #18 above (miniprogramRoot issue)
- The `auto-preview` subcommand is unreliable — use `auto` + `preview` separately instead
- Preview QR codes expire after ~5-10 minutes. Regenerate if the user can't scan in time
- **Regenerate QR for each UAT round** — don't reuse old QR images. The old QR links to a stale build. Always call `preview --qr-format image --qr-output /tmp/wechat_qr/uat_preview_N.png` for each new round.
- **DevTools log may show `start cli server error: [object Object]`** — this is a DevTools internal IPC error during CLI command-handshake and does NOT mean the compile failed or the project is broken. If the `auto` command printed `✔ auto` and `preview` shows a bundle size table, the build is valid. Ignore this error.

See `references/wechat-devtools-cli.md` for all pitfalls (QR path bug, @babel/enhance mode, miniprogramRoot confusion, stale daemon).

## Roadmap / extension ideas

- YOLOv8-pose multi-person for broadcast footage
- Shuttlecock tracking + landing-point heatmap
- 3D reconstruction from multi-camera
- Real-time webcam mode
- Per-player tracking in doubles