---
name: deepseek-provider
description: DeepSeek provider configuration for Hermes Agent — endpoint selection, model mapping, thinking-mode pitfalls.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [deepseek, provider, configuration, troubleshooting]
---

# DeepSeek Provider Configuration

DeepSeek exposes two API endpoints that map to different model behaviors. Choosing the wrong one silently routes to the wrong model class.

## Endpoint vs Model Mapping

| Endpoint | Format | Models | Notes |
|----------|--------|--------|-------|
| `https://api.deepseek.com/v1` | OpenAI-compatible | `deepseek-chat`, `deepseek-chat-v3` | Standard chat models. Use this. |
| `https://api.deepseek.com/anthropic` | Anthropic Messages-compatible | `deepseek-reasoner` (thinking models) | Requires `thinking` block passthrough. Hermes does NOT support this — causes HTTP 400. |

## Configuration

```bash
hermes config set providers.deepseek.base_url "https://api.deepseek.com/v1"
hermes config set model.default "deepseek-chat"
hermes config set model.provider "deepseek"
```

## Pitfall: /anthropic Endpoint

Setting `base_url` to `https://api.deepseek.com/anthropic` silently maps to DeepSeek's reasoning/thinking models regardless of `model.default`. Hermes then fails with:

```
HTTP 400: The `content[].thinking` in the thinking mode must be passed back to the API.
```

This error is **not retryable** and means the wrong endpoint is configured.

## After Fixing Config

Config changes to `model.default` and `providers.deepseek.base_url` require a **new session** (`/reset` or restart Hermes) to take effect. They are read once at session start for prompt caching reasons.
