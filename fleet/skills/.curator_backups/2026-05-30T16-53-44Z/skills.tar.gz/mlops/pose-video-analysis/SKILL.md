---
name: pose-video-analysis
description: Build human-movement analysis pipelines from video using MediaPipe Pose (or similar) — pose estimation, action/event segmentation, biomechanical metric extraction, diagnosis, and annotated-video output. Use for sports technique analysis (badminton/tennis/golf/running form), exercise form checking, gait analysis, gesture/rep counting, or any "analyze how a person moves in this video" task.
---

# Pose-Based Video Movement Analysis

A reusable pipeline for turning a video of a person moving into structured
analysis: per-frame skeleton → detected events (strokes/reps/steps) →
biomechanical metrics → diagnosis → annotated output video.

## Pipeline shape

```
video → PoseEstimator (per-frame 33 landmarks)
      → event segmentation (peak detection on a motion signal)
      → per-event metrics (joint angles, extension, rotation, speed)
      → rule-based diagnosis (+ optional LLM natural-language coaching)
      → visualizer (skeleton + labels burned into output mp4)
```

Keep these as separate modules — `pose_estimator`, `analyzer`,
`coach/diagnoser`, `visualizer`, `cli`. They have independent failure modes
and the analyzer/diagnoser must be testable without real video.

## Critical setup pitfall: MediaPipe version (and the fix for 0.10.35+)

**`mediapipe` builds ≥0.10.20 ship WITHOUT the legacy `mp.solutions` API**.
`import mediapipe as mp; mp.solutions.pose` raises
`AttributeError: module 'mediapipe' has no attribute 'solutions'`.

### Fix option A: pin a version with the legacy API (preferred for existing codebases)

`mediapipe==0.10.14` works (verified on Apple Silicon / Python 3.9+).
Put the exact pin in `requirements.txt`, not a floor (`>=`).

```bash
pip install mediapipe==0.10.14
python -c "import mediapipe as mp; assert hasattr(mp,'solutions'); from mediapipe.python.solutions import pose; print('legacy pose API ok')"
```

### Fix option B: use the new `PoseLandmarker` API (for 0.10.35+)

If the environment already has 0.10.35 (e.g. a Hermes venv), the old API is
simply not available. Switch to the new Task API:

```python
import cv2
import mediapipe as mp
from mediapipe.tasks.python import vision
from mediapipe.tasks.python.core.base_options import BaseOptions

# Step 1: download the model file (one-time)
# curl -L -o pose_landmarker_lite.task \
#   "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task"

options = vision.PoseLandmarkerOptions(
    base_options=BaseOptions(model_asset_path="pose_landmarker_lite.task"),
    running_mode=vision.RunningMode.IMAGE,
    min_pose_detection_confidence=0.4,
)
detector = vision.PoseLandmarker.create_from_options(options)

# Step 2: detect on each image — supports MULTI-PERSON by default
img = cv2.imread("photo.jpg")
mp_img = mp.Image(
    image_format=mp.ImageFormat.SRGB,
    data=cv2.cvtColor(img, cv2.COLOR_BGR2RGB),
)
result = detector.detect(mp_img)  # result.pose_landmarks is a list

# Each element of result.pose_landmarks is a NormalizedLandmarkList
for person_idx, landmarks in enumerate(result.pose_landmarks):
    nose = landmarks[0]
    rwrist = landmarks[16]
    lwrist = landmarks[15]
    # landmarks[i].x, .y, .z are normalized 0-1, same convention as old API
    # No .visibility field in PoseLandmarker output
```

Key differences from the legacy API:
- `PoseLandmarker.create_from_options()` returns more detail (blendshapes, segmentation masks optional)
- **No `.visibility` field** on individual landmarks — all keypoints are assumed visible by the model
- Uses a separate `.task` model file that must be downloaded (~5.7MB for lite)
- The old hand-built `FramePose` dataclass needs to be updated to accept landmarks without the visibility column, or the detection pipeline needs a shim

### Detection of whether legacy API exists (runtime check)

```python
import mediapipe as mp
has_legacy = hasattr(mp, "solutions")
has_tasks = hasattr(mp, "tasks")
# Use the appropriate code path
```

## Key technique: adaptive peak detection for event segmentation

Detecting "when did a stroke/rep/impact happen" from a motion signal
(e.g. dominant-wrist speed = frame-to-frame landmark displacement × fps):

A **pure global threshold** (`mean + std`, or `max * k`) **misses
low-energy events** — a soft drop shot or a light rep never crosses a bar
set by a powerful smash. The fix is **global threshold + local prominence**:

```python
global_thr = max(speeds.mean() + 0.5*speeds.std(), speeds.max() * 0.25)
win = max(int(fps * 0.5), 3)          # local neighborhood ~0.5s
for each local maximum i where speeds[i] >= global_thr:
    baseline = np.median(speeds[i-win : i+win])
    if speeds[i] >= max(global_thr, baseline * 2.0):   # stands out locally
        accept (respecting a min_gap ~0.4s between events)
```

The `baseline * 2.0` local-prominence gate catches softer events the global
bar would drop, while `min_gap` prevents double-counting one motion. Tune
`win`, the prominence multiplier, and `min_gap` to the sport's tempo.

## Always ship a `selftest` that bypasses the CV stack

MediaPipe is trained on real humans — synthetic stick-figure videos get
~17% detection and zero events, so a video-based `demo` can't verify the
analyzer/diagnoser logic. **Add a `selftest` subcommand that constructs
synthetic landmark sequences directly** (hand-built `FramePose` arrays for
a "good" and a "flawed" execution) and runs them through
analyzer → diagnoser → report. This exercises event detection, action
classification, every diagnosis branch, and the coaching output with no
video, no network, no model weights — and it doubles as a regression test
that surfaced the threshold bug above.

## Critical domain limitation: MediaPipe is single-person & near-shot

**MediaPipe Pose is a single-person, near-shot model.** On broadcast /
wide-angle / multi-person footage (e.g. a gym match filmed from the stands,
sports TV coverage) detection rate collapses to near-zero and the few
detected frames produce **garbage biomechanical metrics** (knee_bend 0.00,
recovery 20%, etc.). The analyzer is *not* wrong — the footage type is
wrong for the model.

**Set this expectation BEFORE promising results, and state required footage
up front:** near/medium shot, single person filling a good fraction of the
frame, stable tripod, side/rear ~45° angle. A phone on a tripod of one
player is the ideal input; a downloaded pro match is usually the wrong
input despite being "real badminton." Surface the limitation honestly when
the user supplies broadcast footage rather than reporting confident-looking
but meaningless numbers. If multi-person / wide-angle is a hard
requirement, escalate to a multi-person model (e.g. YOLOv8-pose,
RTMPose) — note this as the upgrade path, don't pretend MediaPipe handles it.

## Reference / pro-comparison module (when "compare to a pro" is asked)

Add a `reference_library` module that scores a user's metrics against a
benchmark and decomposes the gap:

- **Two-tier benchmarks**: ship an expert-prior `BUILTIN_BENCHMARKS` dict
  (per action-type target metric values from coaching norms) so it works
  offline, *and* optionally a `reference_db.json` built from real videos
  that overrides the prior. Load DB on top of priors (merge, DB wins).
- **Build the DB by percentile aggregation, not mean**: run the analyzer
  over a corpus of pro videos, bucket events by action type, take the
  **~75th percentile** of each metric (represents stable high-level
  performance — robust to bad frames, captures "pro target").
- **Scoring**: per-metric `ratio = clip(user/pro, 0, 1)`, weighted sum →
  0–100; surface the single biggest-gap metric so the coach can focus.
- Pitfall: don't feed already-annotated output videos back into
  `build_reference` (double-counts and pollutes the baseline) — only raw
  source clips. Wide-angle pro footage also produces bad baselines for the
  same single-person-model reason above.

## Footwork / locomotion analysis (lower-body sport metrics)

Center-of-mass = midpoint of the two hip landmarks. From its trajectory
derive: total path length, court-coverage bounding box, recovery-to-center
ratio after each event (min distance back to median position within ~0.7s),
stance height (1 − COM.y), stability (inverse of median frame jitter), and
split-step / preparatory-hop count via a fast down-then-up pattern on the
mid-ankle y signal. Gate "recovery/split-step missing" diagnoses on the
presence of detected events (no events ⇒ don't fabricate footwork faults).

## Sourcing reference videos (yt-dlp)

YouTube now hard-walls anonymous downloads ("Sign in to confirm you're not
a bot") even with the android/ios `player_client` extractor args; it
requires real cookies. **macOS Safari cookies are sandbox-protected**
(`Operation not permitted` on `Cookies.binarycookies` without Full Disk
Access) and Chrome/Firefox are often not installed. Robust fallback:
**`archive.org` has openly-licensed real sports footage** — query
`https://archive.org/advancedsearch.php?q=<sport>+AND+mediatype:movies&output=json`,
then `yt_dlp` the `archive.org/details/<id>` page. Use `download_ranges`
with a keyframe-cut callback to grab a short clip instead of a full match.
Keep `cookiesfrombrowser` as an opt-in CLI flag for users who do have
browser cookies available.

## Badminton-specific: multi-action assessment & progressive grading

When building a badminton skill assessment feature (e.g. for a WeChat mini-program), the user's requirement was:

1. **Classify each photo/video into exactly one of 6 badminton strokes**: serve, clear (高远球), drop (吊球), smash (杀球), lift (挑球), net (网前球)
2. **Score each stroke independently** during a multi-photo session
3. **Only produce a final composite grade when ALL 6 strokes have been uploaded** — never give a partial or misleading grade from incomplete data
4. **Reject non-badminton content** before entering the assessment pipeline — distinguish badminton from table tennis, basketball, casual photos, etc.

### Action classification via pose heuristics (photo mode)

For a **single photo** (no speed signal), classify the stroke from body pose alone:

```python
# Key features derived from MediaPipe landmarks:
#   contact_height  = 1.0 - wrist.y  (higher = overhead stroke)
#   arm_extension   = shoulder-elbow-wrist angle / 180°  (1.0 = fully extended)
#   shoulder_rot    = shoulder-line angle vs horizontal / 60° (1.0 = full side-on)
#   knee_bend       = (180° - hip-knee-ankle) / 70° (1.0 = deep lunge)
#   body_lean       = how horizontal the torso-shoulder→hip vector is
#   foot_stance     = "open" (front-back) vs "square" (parallel) via ankle z-diff

# Decision tree (high-confidence branches first):
if height < 0.45 and shoulder_rot < 0.30 and arm_near_horizontal and open_stance:
    → "serve" (发球)       # low hand, forward swing, open stance

if height < 0.35 and knee_bend > 0.30 and arm_ext > 0.55:
    → "lift" (挑球)        # low point, deep knee, arm reaching down

if height < 0.45 and knee_bend > 0.30:
    → "net" (网前球)       # low point, deep lunge

if height > 0.58 and arm_ext > 0.75:
    if lean > 0.20 or shoulder_rot > 0.35:
        → "smash" (杀球)   # high point, full extension, lean forward
    else:
        → "clear" (高远球)  # high point but no lean/rotation

if height > 0.55 and 0.50 ≤ arm_ext ≤ 0.75:
    → "drop" (吊球)        # high point, half-extended (cutting motion)

else fallback:
    → "clear" (low conf)   # unknown → safest default
```

### Multi-photo progressive assessment pattern

Maintain per-user session state:

```python
{
    "user_id": "...",
    "collected": {},       # action_type → {stroke_event, action_score}
    "remaining": [         # actions still needed
        "serve", "clear", "drop", "smash", "lift", "net"
    ],
    "status": "incomplete"  # or "complete"
}
```

Rules:
- Each upload is classified → matched to exactly one of the 6 action types
- If user uploads a 2nd smash, accept it but mark as duplicate (use best score)
- Only when `len(collected) == 6` do you run `SkillGrader.assess(events=list_of_6, source="multi_photo")` with high confidence
- Frontend shows progress bar: `🟢 杀球✅ 🟡 还需要: 吊球 发球 挑球 网前球`
- If user repeatedly uploads the same stroke type, prompt them to try different ones

### Content validation (reject non-badminton)

Add a pre-check before pose → classify:

```python
# Rejection cascade:
# 1. No person detected → "🤔 没看到人呢，请拍打球照片"
# 2. Person but no elevated arm → "肢体动作不太像打球，请重拍"
# 3. Classified action is consistently "clear" with low conf from 3+ attempts
#    → Consider non-badminton content
# 4. Video: inter-event intervals inconsistent with badminton rhythm
#    → Flag for manual review rather than scoring
```

The content validation should be a **separate check** that runs before classification, not mixed into the scoring logic. This keeps the scoring code clean and the rejection reasons user-friendly.

### Video assessment (direct, no frame-splitting needed)

The existing `PoseEstimator.process_video()` already does per-frame analysis. No need to split video into frames manually:

```python
poses = PoseEstimator().process_video(video_path)
events = StrokeAnalyzer(fps=fps).analyze(poses)  # finds all strokes
# Events are naturally multi-type — a rally contains serve, clear, smash...
collected = {e.stroke_type: e for e in set(events)}
if ALL_6_TYPES.issubset(collected):
    grade = SkillGrader().assess(list(collected.values()), source="video")
else:
    missing = ALL_6_TYPES - set(collected)
    grade = partial_result_with_missing_penalty(missing)
```

Video assessment confidence depends on:
- Number of detected strokes per type (more = better consistency estimate)
- Detection stability (frame-to-frame landmark variance)
- If fewer than 2 strokes detected total → fall back to "insufficient data"

### Badminton-specific action: single-frame classifier

The `classify_single_frame(p, side)` function lives in `stroke_analyzer.py` and works for both photo (one FramePose) and video (per-detected-peak) modes. It must handle **no-speed-information** gracefully — photos have zero speed data, so the classifier relies entirely on spatial features.

Pitfall: don't use `wrist_speed` in the single-frame classifier — photos supply a neutral 0.6 placeholder. The height+extension+rotation+lean combination is sufficient.

## Multi-person detection with occlusion-mask fallback

The `PoseLandmarker` API (mediapipe ≥0.10.20) supports multi-person detection natively via `result.pose_landmarks` being a list. However, it frequently **misses partially occluded people** — a second person whose body is behind or overlapping with the first. The occlusion-mask technique improves detection:

```python
def detect_with_occlusion_fallback(image_path: str, max_people: int = 2):
    """Detect bodies, using occlusion masking to find hidden second person."""
    img = cv2.imread(image_path)
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    mp_img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
    
    detector = _get_detector()
    result = detector.detect(mp_img)
    
    people = []
    for landmarks in result.pose_landmarks[:max_people]:
        arr = np.array([[lm.x, lm.y, lm.z, 1.0] for lm in landmarks], dtype=np.float32)
        people.append(arr)
    
    # If we got fewer than max_people, try masking out the first person
    if len(people) < max_people and len(result.pose_landmarks) > 0:
        h, w = img.shape[:2]
        lm0 = result.pose_landmarks[0]
        
        # Compute bounding box of first person + padding
        xs = [lm.x * w for lm in lm0]
        ys = [lm.y * h for lm in lm0]
        pad_x, pad_y = int(w * 0.1), int(h * 0.15)
        x1 = max(0, int(min(xs)) - pad_x)
        x2 = min(w, int(max(xs)) + pad_x)
        y1 = max(0, int(min(ys)) - pad_y)
        y2 = min(h, int(max(ys)) + pad_y)
        
        # Black out the first person's bounding box and re-detect
        masked = rgb.copy()
        masked[y1:y2, x1:x2] = (0, 0, 0)
        mp_masked = mp.Image(image_format=mp.ImageFormat.SRGB, data=masked)
        result2 = detector.detect(mp_masked)
        
        for landmarks in result2.pose_landmarks:
            if len(people) >= max_people:
                break
            arr = np.array([[lm.x, lm.y, lm.z, 1.0] for lm in landmarks], dtype=np.float32)
            people.append((arr, 0.7))  # reduced confidence for fallback detection
    
    return people[:max_people]
```

**Limitation**: This still fails on side-by-side crop where the second person is very small (<30% of first person's size), completely behind the first person, or at extreme angles (profile/back to camera). The fallback is a best-effort attempt, not a guarantee.

### Video mode: full PoseLandmarker pipeline (for 0.10.35+)

When migrating a `PoseEstimator` class from the legacy `mp.solutions.pose.Pose()` API to the new `PoseLandmarker` for **video processing**, the changes involve all four files:

#### `pose_estimator.py` — Video processing refactor

**Before (legacy):**
```python
self._pose = mp.solutions.pose.Pose(
    static_image_mode=False,
    model_complexity=1,
    smooth_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5,
)
# Per frame:
res = self._pose.process(rgb)   # raw numpy rgb
arr = np.array([[p.x, p.y, p.z, p.visibility] for p in res.pose_landmarks.landmark])
```

**After (PoseLandmarker):**
```python
from mediapipe.tasks.python import vision
from mediapipe.tasks.python.core.base_options import BaseOptions

options = vision.PoseLandmarkerOptions(
    base_options=BaseOptions(model_asset_path="pose_landmarker_lite.task"),
    running_mode=vision.RunningMode.VIDEO,     # ← VIDEO mode, not IMAGE
    min_pose_detection_confidence=0.5,
    min_tracking_confidence=0.5,
)
detector = vision.PoseLandmarker.create_from_options(options)

# Per frame:
mp_img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
timestamp_ms = int(frame_idx / fps * 1000)
res = detector.detect_for_video(mp_img, timestamp_ms)   # ← NOT .detect()
arr = None
if res.pose_landmarks:
    arr = np.array([[lm.x, lm.y, lm.z, 1.0] for lm in res.pose_landmarks[0]], dtype=np.float32)
```

**Key differences from IMAGE mode:**
- `running_mode=vision.RunningMode.VIDEO` — IMAGE mode will throw or return empty in video contexts
- `.detect_for_video(mp_img, timestamp_ms)` — NOT `.detect()` (that's for images only)
- `timestamp_ms` must be monotonically increasing — calculated from `int(frame_idx / fps * 1000)`
- Store `self._mp` as an instance attribute so `mp.Image()` is accessible in `process_video()`
- **No `.visibility` field** — all landmarks returned as assumed visible. Update `FramePose.point()` to skip the visibility check (or make it configurable): change `if lm[3] < 0.3: return None` to either remove it or bump the threshold lower
- `PoseLandmarker` objects have no `.close()` method — just set to `None` for cleanup

#### `image_assessor.py` — Image processing refactor

Identical to the IMAGE mode pattern in the skill above. Key changes:
- Replace `with mp.solutions.pose.Pose(static_image_mode=True, ...) as pose:` with `PoseLandmarkerOptions(running_mode=IMAGE)` + `.detect()`
- Model path resolution: check both `os.path.join(os.path.dirname(__file__), "..", "pose_landmarker_lite.task")` and `"pose_landmarker_lite.task"` (project root)
- The `.task` model file must exist before creating options — `FileNotFoundError` if missing. Check `os.path.exists(MODEL)` and fall through candidate paths

#### `double_analyzer.py` — Multi-person detection refactor

Same IMAGE-mode pattern. The new API returns `result.pose_landmarks` as a **list** — no `mp.solutions.pose` context manager needed. The occlusion-mask fallback for detecting a second person works the same way under the new API. 

#### `requirements.txt` pin update

Change `mediapipe==0.10.14` to `mediapipe>=0.10.35` to match the installed version. The old pin locks you to a version with the legacy API; the new pin works with either.

### Version-agnostic runtime check

```python
import mediapipe as mp
has_legacy = hasattr(mp, "solutions")
has_tasks = hasattr(mp, "tasks")
# Branch on this at import/class-init time, not per frame
```

## Other lessons

- **Diagnosis = rules, narrative = optional LLM.** Rule engine produces the
  metrics/issues; LLM only rephrases into coaching prose. Gate the LLM on
  `ANTHROPIC_API_KEY`/`OPENAI_API_KEY` and **always fall back to the rule
  report** on any LLM exception so the pipeline runs fully offline.
- **CJK string literals**: avoid embedding ASCII `"` inside Chinese strings
  (`变成"抬手臂"打球`) — Python parses the inner `"` as a string terminator
  → `SyntaxError`. Use `「」` / `『』` / `'…'` for inner quotes.
- **Dominant side detection**: pick the limb (left vs right wrist) with
  higher positional variance rather than assuming right-handed.
- **Joint metrics**: extension = shoulder-elbow-wrist angle / 180; rotation
  = angle of the two-shoulder line vs horizontal; knee bend =
  (180 − hip-knee-ankle angle). Normalize all to 0–1 for reporting + bars.
- Skip landmarks with `visibility < 0.3` as unreliable rather than trusting
  every detected point.

## Verification

`scripts/verify_mediapipe.py` checks the install has the `solutions` API.
Run it right after `pip install` before building anything on top.

`templates/selftest_synthetic_landmarks.py` is a copy-and-adapt harness
that hand-builds MediaPipe-format landmark arrays (with the 33-index map
documented inline) and runs analyzer → footwork → comparison → coach with
no video/network/weights. Reproduce-with-modifications: shape its two
motion segments to a good vs flawed execution for the target sport.

## Reference

`references/badminton-action-classifier.md` — full 6-action signature table,
decision trees for photo and video mode, diagnosis rules per action type.
Load when building a badminton-specific assessment feature.

`references/mediapipe-0.10.35-migration.md` — complete 4-file migration
spec from `mp.solutions.pose` to `PoseLandmarker` API (pose_estimator,
image_assessor, double_analyzer, and requirements.txt). Load when you hit
`AttributeError: module 'mediapipe' has no attribute 'solutions'` and the
installed version is ≥0.10.20.

`references/synthetic-landmark-parameter-mapping.md` — how to verify that
synthetic landmark test-data helpers actually produce the feature values
their parameter names imply (invert-the-real-function pattern). Load when
building or debugging a `make_landmarks`-style test helper for ML
feature-extraction code. Every classifier/analyzer bug you can't reproduce
with synthetic data is probably a helper-geometry bug, not a production bug.
