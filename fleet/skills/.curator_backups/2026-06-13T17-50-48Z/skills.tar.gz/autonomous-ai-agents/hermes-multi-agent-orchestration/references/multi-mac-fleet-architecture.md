# Multi-Mac Hermes Fleet Architecture

## When to use
User has 3-5 Macs and wants Hermes to orchestrate across all of them with:
- One Mac as Origin (始祖) — runs cron, dashboard, authorization
- Other Macs as workers — execute tasks, each managing 1-3 projects
- Shared skills/profiles across fleet
- Independent local memory (state.db) per Mac

## Architecture

```
                    GitHub: hermes-fleet-config (private repo)
                         ↙   ↓   ↘
        ┌──────────────┬──────────────┬──────────────┐
        │   Mac-A      │   Mac-B      │   Mac-C      │
        │   始祖舰      │   执行舰      │   执行舰      │
        ├──────────────┼──────────────┼──────────────┤
        │ Cron 全部     │ 项目1-2       │ 项目3-4       │
        │ Dashboard     │ PM Agent     │ PM Agent     │
        │ 授权引擎      │              │              │
        ├──────────────┼──────────────┼──────────────┤
        │ skills (权威) │ skills (同步) │ skills (同步) │
        │ profiles(权威)│ profiles(同步)│ profiles(同步)│
        │ state.db(本地)│ state.db(本地)│ state.db(本地)│
        └──────────────┴──────────────┴──────────────┘
```

## Design Principles

1. **ONE Origin per fleet.** Origin holds cron, dashboard, authorization engine. Determined by who runs `apex fleet-init`.
2. **Worker Macs pull config from Git.** `apex fleet-join` clones the Origin's config repo into `~/.hermes/`.
3. **state.db is local per Mac.** Memory/context does NOT sync across Macs. Each Mac has its own conversation history.
4. **Origin transfer requires dual-approval.** New Origin runs `apex origin-request`. Current Origin runs `apex origin-approve <code>`.
5. **Projects assigned per Mac.** Each Mac typically manages 1-3 projects with a PM agent.

## Apex Fleet Commands

```bash
# On Origin Mac:
apex fleet-init -n "FleetName" -r https://github.com/user/hermes-fleet-config

# On Worker Macs:
apex fleet-join -r https://github.com/user/hermes-fleet-config

# Status:
apex fleet-status        # All nodes, roles, projects
apex fleet-sync          # Git pull/push config
apex origin-status       # Check Origin role

# Origin transfer:
apex origin-request -r "reason"
apex origin-approve <code>

# Project bootstrap:
apex project-init myapp --pm pm-agent --template webapp
apex project-team myapp
apex project-report myapp
```

## Implementation

Core module: `apex/core/fleet.py` — FleetManager class
CLI module: `apex/cli_fleet.py` — registers 10 commands on main Typer app

## Pitfalls

- **Network proxy blocks git push**: If SSH port 22 and HTTPS both fail with SSL_ERROR_SYSCALL, try fresh repo approach (see `references/git-push-troubleshooting.md`).
- **Origin must be unique**: Only one Mac can run cron. Worker Macs must NOT have cron jobs enabled.
- **state.db conflict**: Never git-commit state.db. It's in .gitignore by default.
- **Config drift**: After changing skills/profiles on Origin, run `apex fleet-sync` and have workers run it too.
